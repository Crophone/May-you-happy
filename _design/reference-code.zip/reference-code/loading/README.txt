A Pen created at CodePen.io. You can find this one at http://codepen.io/jackrugile/pen/BlDjk.

 A canvas loader that sparks light from red to green.