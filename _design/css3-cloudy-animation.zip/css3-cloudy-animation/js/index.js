// Set out to build a loading indicator 
// but ended up with this cloudy spiral 
// animation.
//
// - Hakim | @hakimel